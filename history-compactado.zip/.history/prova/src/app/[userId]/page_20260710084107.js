export default function detail(){
    
}